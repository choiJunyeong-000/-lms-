import React, { useState, useEffect, useCallback } from 'react';
import axios from 'axios';
import './TeamProjectSubmit.css';

function TeamProjectSubmit() {
  const [files, setFiles] = useState([]);
  const [deadline, setDeadline] = useState(null);
  const [teamName, setTeamName] = useState("알 수 없는 팀");
  const [teamId, setTeamId] = useState(null);
  const [teamProjectId, setTeamProjectId] = useState(null);
  const [deadlinePassed, setDeadlinePassed] = useState(false);
  const [feedbackMessage, setFeedbackMessage] = useState("");
  const [isReady, setIsReady] = useState(false);
  const token = localStorage.getItem("token");

  // ✅ 팀 ID 및 프로젝트 ID 가져오기
  useEffect(() => {
    if (!token) {
      console.warn("⚠️ 토큰이 없습니다. 로그인이 필요합니다.");
      setFeedbackMessage("로그인이 필요합니다.");
      return;
    }

    const fetchTeamInfo = async () => {
      try {
        const userResponse = await axios.get("http://localhost:8090/api/users/me", {
          headers: { Authorization: `Bearer ${token}` }
        });

        if (!userResponse.data || !userResponse.data.id) {
          setFeedbackMessage("학생 정보를 찾을 수 없습니다.");
          return;
        }
        const studentId = userResponse.data.id;

        const teamMembersResponse = await axios.get("http://localhost:8090/api/team-members", {
          headers: { Authorization: `Bearer ${token}` }
        });

        const studentTeam = teamMembersResponse.data.find(member => member.member_id === studentId);

        if (!studentTeam) {
          setFeedbackMessage("학생이 속한 팀이 없습니다.");
          return;
        }

        const studentTeamId = studentTeam.team_id;
        setTeamId(studentTeamId);

        const projectsResponse = await axios.get(`http://localhost:8090/api/team-projects?teamId=${studentTeamId}`, {
          headers: { Authorization: `Bearer ${token}` }
        });

        if (!projectsResponse.data || projectsResponse.data.length === 0) {
          setFeedbackMessage("이 팀에 등록된 프로젝트가 없습니다.");
          return;
        }

        const teamProject = projectsResponse.data[0];
        setTeamProjectId(teamProject.teamProjectId);
        setTeamName(teamProject.projectName || "알 수 없는 팀");
        setDeadline(new Date(teamProject.deadline));

        // ✅ 모든 데이터가 정상적으로 설정되면 isReady 활성화
        setIsReady(true);

      } catch (error) {
        setFeedbackMessage("팀 정보를 불러오는 중 오류가 발생했습니다.");
      }
    };

    fetchTeamInfo();
  }, [token]);

  // ✅ 마감일 체크
  useEffect(() => {
    if (deadline && new Date() > deadline) {
      setDeadlinePassed(true);
    }
  }, [deadline]);

  const handleFileChange = useCallback((e) => {
    setFiles(Array.from(e.target.files));
  }, []);

  const handleRemoveFile = useCallback((index) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
  }, []);

  // ✅ 최종 제출 버튼
  const handleSubmit = useCallback(async () => {
    if (!teamId || !teamProjectId) {
      setFeedbackMessage("팀 정보를 불러오는 중입니다. 잠시 후 다시 시도해주세요.");
      return;
    }
    if (files.length === 0) {
      setFeedbackMessage("파일을 업로드하세요!");
      return;
    }
    if (deadlinePassed) {
      setFeedbackMessage("제출 기한이 지났습니다.");
      return;
    }

    const formData = new FormData();
    formData.append("file", files[0]);

    try {
      await axios.post(
        `http://localhost:8090/api/team-project-submissions/${teamProjectId}/${teamId}/submit`,
        formData,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      setFeedbackMessage("프로젝트가 성공적으로 제출되었습니다!");
      setFiles([]);
    } catch (error) {
      setFeedbackMessage("제출 중 오류가 발생했습니다.");
    }
    setTimeout(() => setFeedbackMessage(""), 3000);
  }, [files, deadlinePassed, teamId, teamProjectId, token]);

  return (
    <div className="team-project-submit">
      <h2>팀 프로젝트 제출 ({teamName})</h2>
      {feedbackMessage && <div className="feedback-message" role="alert">{feedbackMessage}</div>}
      {deadlinePassed ? (
        <p className="deadline-message">제출 기한이 지났습니다.</p>
      ) : (
        <>
          <label htmlFor="file-upload" className="visually-hidden">파일 업로드</label>
          <input
            id="file-upload"
            type="file"
            onChange={handleFileChange}
            accept=".zip,.pdf,.docx,.pptx"
            multiple
            disabled={!isReady || deadlinePassed}
          />
          <ul>
            {files.map((file, index) => (
              <li key={index}>
                {file.name}{' '}
                <button onClick={() => handleRemoveFile(index)}>삭제</button>
              </li>
            ))}
          </ul>
          <button onClick={handleSubmit} disabled={!isReady || deadlinePassed}>
            제출하기
          </button>
        </>
      )}
    </div>
  );
}

export default TeamProjectSubmit;
