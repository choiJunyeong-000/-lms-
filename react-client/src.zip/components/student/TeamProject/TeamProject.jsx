import React, { useState, useEffect } from 'react';
import axios from 'axios';
import TeamProjectSubmit from './TeamProjectSubmit';
import TeamProjectHistory from './TeamProjectHistory';
import './TeamProject.css';

const TeamProject = () => {
  const [activeTab, setActiveTab] = useState('');
  const [studentInfo, setStudentInfo] = useState(null);
  const [teamProjects, setTeamProjects] = useState([]);
  const [teamMembers, setTeamMembers] = useState([]);
  const [loading, setLoading] = useState(true);
  const token = localStorage.getItem("token");

  useEffect(() => {
    if (!token) {
      return;
    }

    const fetchData = async () => {
      try {
        const [userResponse, teamMembersResponse] = await Promise.all([
          axios.get("http://localhost:8090/api/users/me", { headers: { Authorization: `Bearer ${token}` } }),
          axios.get("http://localhost:8090/api/team-members", { headers: { Authorization: `Bearer ${token}` } })
        ]);

        const student = userResponse.data;
        setStudentInfo(student);

        const studentTeams = teamMembersResponse.data
          .filter(member => member.member_id === student.id)
          .map(member => member.team_id);

        if (studentTeams.length === 0) {
          setLoading(false);
          return;
        }

        const projectsResponse = await axios.get("http://localhost:8090/api/team-projects", {
          headers: { Authorization: `Bearer ${token}` },
          params: { teamId: studentTeams[0] },
        });
        
        setTeamProjects(projectsResponse.data);
        setTeamMembers(teamMembersResponse.data.filter(member => studentTeams.includes(member.team_id)));
      } catch (error) {
        console.error("데이터 로딩 실패:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [token]);

  if (loading) {
    return <div>데이터 불러오는 중...</div>;
  }

  return (
    <div className="team-project-container">
      <main className="team-project-content">
        <div className="team-project-list">
          <h2>{studentInfo?.name}님의 팀 프로젝트</h2>
          {teamProjects.length > 0 ? (
            teamProjects.map((project) => (
              <div key={project.team_id} className="team-project-card">
                <h3>{project.projectName}</h3>
                <p>
                  마감일: <strong>{new Date(project.deadline).toLocaleDateString()}</strong>
                </p>
              </div>
            ))
          ) : (
            <p>등록된 팀 프로젝트가 없습니다.</p>
          )}

          <h3>전체 팀원</h3>
          <ul className="team-project-members">
            {teamMembers.length > 0 ? (
              teamMembers.map((member) => (
                <li key={member.member?.id || member.id}>
                  {member.member?.name || member.name}
                </li>
              ))
            ) : (
              <p>팀원이 없습니다.</p>
            )}
          </ul>
        </div>

        <div className="team-project-tabs">
          <button
            className={activeTab === 'submit' ? 'active' : ''}
            onClick={() => setActiveTab(activeTab === 'submit' ? '' : 'submit')}
          >
            제출
          </button>
          <button
            className={activeTab === 'history' ? 'active' : ''}
            onClick={() => setActiveTab(activeTab === 'history' ? '' : 'history')}
          >
            제출 내역
          </button>
        </div>

        {activeTab === 'submit' && <TeamProjectSubmit />}
        {activeTab === 'history' && <TeamProjectHistory />}
      </main>
    </div>
  );
};

export default TeamProject;