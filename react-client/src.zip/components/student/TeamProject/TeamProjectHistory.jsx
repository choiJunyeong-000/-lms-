import React, { useState, useEffect, useMemo } from 'react';
import axios from 'axios';
import './TeamProjectHistory.css';

function TeamProjectHistory() {
  const [studentInfo, setStudentInfo] = useState(null);
  const [teamId, setTeamId] = useState(null);
  const [submissions, setSubmissions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const token = localStorage.getItem("token");

  // DTO 구조에 맞춰 submission.teamId로 필터링
  const filteredSubmissions = useMemo(() => {
    return Array.isArray(submissions)
      ? submissions.filter(submission => submission.teamId === teamId)
      : [];
  }, [submissions, teamId]);
  
  useEffect(() => {
    if (!token) {
      console.warn("⚠️ 토큰이 없습니다. 로그인이 필요합니다.");
      setError("로그인이 필요합니다.");
      setLoading(false);
      return;
    }

    const fetchStudentData = async () => {
      try {
        // 1️⃣ 로그인한 학생 정보 가져오기
        const userResponse = await axios.get("http://localhost:8090/api/users/me", {
          headers: { Authorization: `Bearer ${token}` }
        });
        if (!userResponse.data || !userResponse.data.id) {
          console.warn("⚠️ 학생 정보를 찾을 수 없습니다.");
          setError("학생 정보를 찾을 수 없습니다.");
          return;
        }
        const studentId = userResponse.data.id;
        setStudentInfo(userResponse.data);

        // 2️⃣ 팀원 목록에서 학생이 속한 팀 ID 찾기
        const teamMembersResponse = await axios.get("http://localhost:8090/api/team-members", {
          headers: { Authorization: `Bearer ${token}` }
        });
        console.log("📌 팀원 목록 응답:", teamMembersResponse.data);

        const studentTeam = teamMembersResponse.data.find(member => member.member_id === studentId);
        if (!studentTeam || !studentTeam.team_id) {
          console.warn("⚠️ 학생이 속한 팀을 찾을 수 없습니다.");
          setError("학생이 속한 팀이 없습니다.");
          return;
        }
        const studentTeamId = studentTeam.team_id;
        console.log(`✅ 학생이 속한 팀 ID: ${studentTeamId}`);
        setTeamId(studentTeamId);

        // 3️⃣ 해당 팀의 프로젝트 제출 내역 가져오기 (DTO 형태)
        const submissionsResponse = await axios.get("http://localhost:8090/api/team-project-submissions", {
          headers: { Authorization: `Bearer ${token}` },
          params: { teamId: studentTeamId }
        });
        
        console.log("📂 제출 내역 응답:", submissionsResponse.data);
        if (!submissionsResponse.data || !Array.isArray(submissionsResponse.data)) {
          console.warn("⚠️ 제출 내역이 없습니다.");
          setError("이 팀에서 제출한 프로젝트가 없습니다.");
          return;
        }
        setSubmissions(submissionsResponse.data);
      } catch (error) {
        console.error("⚠️ 데이터 로딩 실패:", error);
        setError("데이터를 불러오는 중 오류가 발생했습니다.");
      } finally {
        setLoading(false);
      }
    };

    fetchStudentData();
  }, [token]);

  if (loading) {
    return (
      <div className="team-project-history">
        <h2>팀 프로젝트 제출 내역</h2>
        <p>📡 데이터 불러오는 중...</p>
      </div>
    );
  }

  return (
    <div className="team-project-history">
      <h2>팀 프로젝트 제출 내역</h2>
      {error ? (
        <p className="error-message">{error}</p>
      ) : filteredSubmissions.length === 0 ? (
        <p>제출된 프로젝트가 없습니다.</p>
      ) : (
        <table className="history-table">
          <thead>
            <tr>
              <th>팀명</th>
              <th>제출 파일</th>
              <th>제출 시간</th>
            </tr>
          </thead>
          <tbody>
            {filteredSubmissions.map((submission, index) => (
              <tr key={`${submission.id}-${index}`}>
                <td>{submission.teamName || '팀명 미지정'}</td>
                <td>
                  {submission.files ? (
                    <a href={`/uploads/${submission.files}`} download>
                      {submission.files}
                    </a>
                  ) : (
                    <span>파일 없음</span>
                  )}
                </td>
                <td>{new Date(submission.submittedAt).toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

export default TeamProjectHistory;
