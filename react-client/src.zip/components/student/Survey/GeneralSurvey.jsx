import React, { useState, useEffect, useMemo } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function GeneralSurvey({ onComplete }) {
  const navigate = useNavigate();
  const [groupedSurveys, setGroupedSurveys] = useState({});
  const [selectedSurveyType, setSelectedSurveyType] = useState(null);
  const [selectedTimeGroup, setSelectedTimeGroup] = useState(null); // 시간 그룹 선택 상태
  const [responses, setResponses] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [memberId, setMemberId] = useState(null);
  const token = useMemo(() => localStorage.getItem("token"), []);

  const surveyTypeNames = {
    "GENERAL_SURVEY": "정기 설문조사",
    "MEAL_SURVEY": "정기 급식 만족도",
    "ACADEMIC_SURVEY": "정기 학교 설문"
  };

  // 사용자 정보 가져오기
  useEffect(() => {
    if (!token) {
      setError("로그인이 필요합니다.");
      setLoading(false);
      return;
    }
    const fetchUserInfo = async () => {
      try {
        const response = await axios.get('http://localhost:8090/api/users/me', {
          headers: { Authorization: `Bearer ${token}` }
        });
        setMemberId(response.data.id);
      } catch (error) {
        alert("사용자 정보를 불러올 수 없습니다. 다시 로그인해주세요.");
        navigate('/login');
      }
    };
    fetchUserInfo();
  }, [token, navigate]);

  // 설문 데이터 가져와서 시간별 그룹으로 묶기
  useEffect(() => {
    if (!token || !memberId) return;
    const fetchSurveys = async () => {
      try {
        const response = await axios.get('http://localhost:8090/api/surveys', {
          headers: { Authorization: `Bearer ${token}` }
        });
        console.log("survey data:", response.data);

        const grouped = response.data.reduce((acc, survey) => {
          // 특정 surveyType 제외 (필요시 조건 수정)
          if (survey.surveyType === "LECTURE_EVALUATION" || survey.surveyType === "TEAM_EVALUATION") {
            return acc;
          }
          if (!acc[survey.surveyType]) {
            acc[survey.surveyType] = {};
          }
          // 날짜 필드명이 start_date 또는 startDate 둘 중 하나일 수 있음
          const dateField = survey.start_date || survey.startDate || null;
          const startDateKey = dateField 
            ? new Date(dateField).toLocaleString() 
            : "미정";
          if (!acc[survey.surveyType][startDateKey]) {
            acc[survey.surveyType][startDateKey] = [];
          }
          acc[survey.surveyType][startDateKey].push(survey);
          return acc;
        }, {});
        setGroupedSurveys(grouped);
        setLoading(false);
      } catch (error) {
        setError("설문 데이터를 불러오는 중 오류가 발생했습니다.");
        setLoading(false);
      }
    };
    fetchSurveys();
  }, [token, memberId]);

  // 설문 유형 선택 시
  const handleSelectSurveyType = (surveyType) => {
    setSelectedSurveyType(surveyType);
    setSelectedTimeGroup(null); // 그룹 목록 보기 상태로 전환
    setResponses({});
  };

  // 시간 그룹(설문 목록) 선택 시
  const handleSelectTimeGroup = (groupKey) => {
    setSelectedTimeGroup(groupKey);
    setResponses({});
  };

  // 제출 처리 (선택한 그룹의 설문만 처리)
  const handleSubmit = async () => {
    const currentGroupSurveys = groupedSurveys[selectedSurveyType][selectedTimeGroup];
    if (Object.keys(responses).length !== currentGroupSurveys.length) {
      alert("모든 질문에 답변해야 합니다!");
      return;
    }
  
    // 중복 체크
    for (let [questionId] of Object.entries(responses)) {
      try {
        await axios.post(
          "http://localhost:8090/api/survey-responses/check",
          { surveyId: questionId, memberId: memberId },
          { headers: { Authorization: `Bearer ${token}` } }
        );
      } catch (error) {
        if (error.response && error.response.status === 400) {
          alert(error.response.data);
          return;
        } else {
          alert("중복 체크 중 오류가 발생했습니다.");
          return;
        }
      }
    }
  
    const requestData = {
      memberId: memberId,
      responses: Object.entries(responses).map(([questionId, response]) => ({
        surveyId: questionId,
        response: response
      }))
    };
  
    try {
      await axios.post("http://localhost:8090/api/survey-responses/submit", requestData, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setSubmitted(true);
      alert("✅ 설문이 성공적으로 제출되었습니다!");
      if (onComplete) onComplete();
    } catch (error) {
      alert("설문 제출 중 오류가 발생했습니다.");
    }
  };

  // 설문 유형 목록으로 돌아가기
  const handleBackToSurveyType = () => {
    setSelectedSurveyType(null);
    setSelectedTimeGroup(null);
    setResponses({});
  };

  // 시간 그룹(설문 목록) 화면으로 돌아가기
  const handleBackToGroupList = () => {
    setSelectedTimeGroup(null);
    setResponses({});
  };

  if (loading) return <p>📡 설문 데이터를 불러오는 중...</p>;
  if (error) return <p className="error-message">{error}</p>;
  if (submitted) {
    return (
      <div>
        <p>🎉 설문이 제출되었습니다! 감사합니다.</p>
        <button onClick={handleBackToSurveyType}>설문 유형 목록으로 돌아가기</button>
      </div>
    );
  }

  // 설문 유형 선택 화면
  if (!selectedSurveyType) {
    return (
      <div className="survey-container">
        <h2>설문 유형 선택</h2>
        {Object.keys(groupedSurveys).map((type) => (
          <li key={type}>
            {surveyTypeNames[type] || type}{" "}
            <button onClick={() => handleSelectSurveyType(type)}>설문 선택</button>
          </li>
        ))}
      </div>
    );
  }

  // 선택한 설문 유형 내 시간 그룹(설문 목록) 화면
  if (selectedSurveyType && !selectedTimeGroup) {
    const groupKeys = Object.keys(groupedSurveys[selectedSurveyType]);
    return (
      <div className="survey-container">
        <h2>{surveyTypeNames[selectedSurveyType] || selectedSurveyType} 설문 목록</h2>
        <ul>
          {groupKeys.map((groupKey) => (
            <li key={groupKey}>
              {groupKey} ({groupedSurveys[selectedSurveyType][groupKey].length}문항)
              <button onClick={() => handleSelectTimeGroup(groupKey)}>해당 설문 시작</button>
            </li>
          ))}
        </ul>
        <button onClick={handleBackToSurveyType}>설문 유형 목록으로 돌아가기</button>
      </div>
    );
  }

  // 선택한 시간 그룹의 설문 질문 화면
  if (selectedSurveyType && selectedTimeGroup) {
    const currentGroupSurveys = groupedSurveys[selectedSurveyType][selectedTimeGroup];
    return (
      <div className="survey-container">
        <h2>{surveyTypeNames[selectedSurveyType] || selectedSurveyType} 설문</h2>
        <h3>{selectedTimeGroup}</h3>
        {currentGroupSurveys.map((survey) => (
          <div key={survey.id}>
            <p>{survey.title}</p>
            <div>
              {survey.options.split(',').map(option => (
                <label key={option}>
                  <input
                    type="radio"
                    name={`question-${survey.id}`}
                    value={option}
                    checked={responses[survey.id] === option}
                    onChange={() =>
                      setResponses(prev => ({ ...prev, [survey.id]: option }))
                    }
                  />
                  {option}
                </label>
              ))}
            </div>
          </div>
        ))}
        <button onClick={handleBackToGroupList}>목록으로 돌아가기</button>
        <button onClick={handleSubmit}>제출</button>
      </div>
    );
  }

  return null;
}

export default GeneralSurvey;
