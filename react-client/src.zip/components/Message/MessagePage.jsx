import React, { useState, useEffect } from 'react';
import { io } from 'socket.io-client';
import axios from 'axios';
import { v4 as uuidv4 } from 'uuid'; // ✅ UUID 추가
import './MessagePage.css';

const socket = io('http://localhost:5000');

const MessagePage = () => {
  const [member, setMember] = useState(null);
  const [messages, setMessages] = useState([]);
  const [inputText, setInputText] = useState('');
  const [recipient, setRecipient] = useState(null);
  const [members, setMembers] = useState([]);

  // ✅ 로그인한 사용자 정보 및 전체 멤버 조회
  useEffect(() => {
    async function fetchMemberData() {
      try {
        const token = localStorage.getItem("token");
        const resMe = await axios.get('http://localhost:8090/api/users/me', {
          headers: { Authorization: `Bearer ${token}` }
        });
        setMember(resMe.data);

        const resMembers = await axios.get('http://localhost:8090/api/chat-members', {
          headers: { Authorization: `Bearer ${token}` }
        });

        const otherMembers = resMembers.data.filter(m => m.studentId !== resMe.data.studentId);
        setMembers(otherMembers);
      } catch (error) {
        console.error("🚨 멤버 정보를 불러오는 데 실패했습니다.", error);
      }
    }
    fetchMemberData();
  }, []);

  // ✅ 백엔드에서 채팅 내역 가져오기
  useEffect(() => {
    async function fetchMessages() {
      if (!member || !recipient) return;

      try {
        const token = localStorage.getItem("token");
        if (!token) {
          console.error("🚨 JWT 토큰 없음. 로그인 필요");
          return;
        }

        const response = await axios.get(`http://localhost:8090/api/chat/messages/${member.studentId}`, {
          headers: { Authorization: `Bearer ${token}` }
        });

    

        setMessages(response.data);
      } catch (error) {
        console.error("🚨 채팅 내역을 불러오지 못했습니다.", error);
      }
    }

    fetchMessages();
  }, [member, recipient]);

  // ✅ 실시간 메시지 수신 (이전 리스너 정리)
  useEffect(() => {
    const handleMessageReceive = (msg) => {
     

  
      setMessages(prev => {
        if (prev.some(m => m.id === msg.id)) { // ✅ 중복 메시지 필터링
          console.warn("⚠️ 중복 메시지 감지 - 추가 안 함", msg);
          return prev;
        }
        return [...prev, msg];
      });
    };
  
    socket.off('chat message');  // ✅ 기존 이벤트 제거
    socket.on('chat message', handleMessageReceive);  // ✅ 새로운 리스너 등록
  
    return () => {
      socket.off('chat message', handleMessageReceive);  // ✅ 언마운트 시 정리
    };
  }, [member, recipient]);
  

  // ✅ 메시지 전송 처리
  const handleSend = async () => {
    const trimmedText = inputText.trim();
    if (!trimmedText || !recipient || !member) return;

    const newMsg = {
      sender: member.studentId,
      recipient: recipient.studentId,
      content: trimmedText
    };

    try {
      const response = await axios.post("http://localhost:8090/api/chat/send", newMsg, {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` }
      });

      // ✅ UUID 활용하여 key 중복 문제 해결
      setMessages((prev) => [
        ...prev,
        { ...response.data, id: response.data.id || uuidv4() }
      ]);

      socket.emit('chat message', response.data);
      setInputText('');
    } catch (error) {
      console.error("🚨 메시지 전송 실패", error);
    }
  };

  return (
    <div className="message-page-container">
      <div className="chat-area">
        <div className="chat-header">
          {member && recipient 
            ? `${member.name}과 ${recipient.name}의 대화`
            : "수신자를 선택하세요"}
        </div>

        <div className="recipient-selector">
          <label>받는 사람: </label>
          <select onChange={(e) => setRecipient(members.find(m => m.studentId === e.target.value))}>
            <option value="" disabled>📩 받는 사람을 선택하세요</option>
            {members.map(m => (
              <option key={m.studentId} value={m.studentId}>
                {m.name}
              </option>
            ))}
          </select>
        </div>

        <div className="chat-messages">
          {messages.map((msg) => (
            <div key={msg.id || uuidv4()} // ✅ UUID 활용하여 중복 키 방지
                 className={`chat-message ${msg.sender === member?.studentId ? 'sent' : 'received'}`}>
              <span>{msg.sender}: </span>
              <span>{msg.content}</span>
            </div>
          ))}
        </div>

        <div className="chat-input">
          <input 
            type="text" 
            value={inputText} 
            onChange={(e) => setInputText(e.target.value)} 
            placeholder="메시지를 입력하세요..." 
          />
          <button onClick={handleSend}>전송</button>
        </div>
      </div>
    </div>
  );
};

export default MessagePage;
