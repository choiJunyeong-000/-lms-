import React, { useEffect, useState } from "react";
import axios from "axios";
// react-chartjs-2 & chart.js 불러오기
import { Bar } from "react-chartjs-2";
import { Chart as ChartJS } from "chart.js/auto";

const AdminSurveyResponses = () => {
  const token = localStorage.getItem("token");

  const [groupedSurveys, setGroupedSurveys] = useState({});
  const [loadingSurveys, setLoadingSurveys] = useState(true);
  const [errorSurveys, setErrorSurveys] = useState(null);

  // 설문별 응답 캐싱: { [surveyId]: [응답1, 응답2, ...], ... }
  const [responsesBySurvey, setResponsesBySurvey] = useState({});
  const [expandedGroups, setExpandedGroups] = useState({});

  // 1) 전체 설문 목록 불러오기
  useEffect(() => {
    const fetchSurveys = async () => {
      try {
        const res = await axios.get("http://localhost:8090/api/surveys", {
          headers: { Authorization: token ? `Bearer ${token}` : "" },
        });
        const surveys = res.data;

        // surveyType -> titleKey
        const groups = surveys.reduce((acc, survey) => {
          const type = survey.surveyType;
          if (!acc[type]) {
            acc[type] = {};
          }
          const titleKey = survey.title || "제목없음";
          if (!acc[type][titleKey]) {
            acc[type][titleKey] = [];
          }
          acc[type][titleKey].push(survey);
          return acc;
        }, {});
        setGroupedSurveys(groups);
      } catch (err) {
        console.error("설문 목록 불러오기 오류:", err);
        setErrorSurveys("설문 목록을 불러오는 데 실패했습니다.");
      } finally {
        setLoadingSurveys(false);
      }
    };
    fetchSurveys();
  }, [token]);

  // 2) 특정 설문의 응답 불러오기
  const fetchResponses = async (surveyId) => {
    try {
      const res = await axios.get(
        `http://localhost:8090/api/survey-responses/${surveyId}`,
        {
          headers: { Authorization: token ? `Bearer ${token}` : "" },
        }
      );
      setResponsesBySurvey((prev) => ({
        ...prev,
        [surveyId]: res.data,
      }));
    } catch (err) {
      console.error(`설문 ${surveyId} 응답 불러오기 오류:`, err);
      alert(`설문 ${surveyId} 응답을 불러오는 데 실패했습니다.`);
    }
  };

  // 3) 그룹 전체 펼침
  const handleViewGroupSubmissions = async (type, titleKey) => {
    const group = groupedSurveys[type][titleKey];
    for (const survey of group) {
      if (!responsesBySurvey[survey.id]) {
        await fetchResponses(survey.id);
      }
    }
    setExpandedGroups((prev) => ({
      ...prev,
      [`${type}-${titleKey}`]: !prev[`${type}-${titleKey}`],
    }));
  };

  if (loadingSurveys) return <div>설문 목록 로딩 중...</div>;
  if (errorSurveys) return <div style={{ color: "red" }}>{errorSurveys}</div>;

  return (
    <div style={{ maxWidth: "800px", margin: "0 auto" }}>
      <h2 style={{ textAlign: "center" }}>
        관리자: 설문 응답 (타입별, 제목별 그룹, 각 설문별 옵션 빈도 - Bar 차트)
      </h2>

      {Object.keys(groupedSurveys).map((type) => (
        <div key={type} style={{ marginBottom: "2rem" }}>
          <h3 style={{ color: "#007bff", marginBottom: "1rem" }}>{type}</h3>

          {Object.keys(groupedSurveys[type]).map((titleKey) => {
            const group = groupedSurveys[type][titleKey];
            const groupKey = `${type}-${titleKey}`;
            const isExpanded = expandedGroups[groupKey];

            return (
              <div
                key={titleKey}
                style={{
                  border: "1px solid #ccc",
                  borderRadius: "8px",
                  padding: "1rem",
                  marginBottom: "1rem",
                }}
              >
                <h4 style={{ marginBottom: "0.5rem" }}>{titleKey}</h4>
                <button
                  onClick={() => handleViewGroupSubmissions(type, titleKey)}
                  style={{
                    background: "#0069d9",
                    color: "#fff",
                    padding: "6px 12px",
                    border: "none",
                    borderRadius: "4px",
                    cursor: "pointer",
                  }}
                >
                  {isExpanded ? "응답 숨기기" : "응답 보기"}
                </button>

                {isExpanded && (
                  <div style={{ marginTop: "1rem", paddingLeft: "1rem" }}>
                    {group.map((survey) => {
                      const surveyResponses = responsesBySurvey[survey.id] || [];
                      // 옵션별 빈도 수 계산
                      const optionCounts = {};
                      surveyResponses.forEach((resp) => {
                        const chosenOption = resp.response;
                        if (!optionCounts[chosenOption]) {
                          optionCounts[chosenOption] = 0;
                        }
                        optionCounts[chosenOption]++;
                      });

                      // Bar 차트를 위한 데이터 구성
                      const labels = Object.keys(optionCounts);
                      const data = labels.map((label) => optionCounts[label]);

                      // chart.js 에 전달할 데이터셋
                      const chartData = {
                        labels,
                        datasets: [
                          {
                            label: "응답 인원",
                            data,
                            backgroundColor: "rgba(75,192,192,0.4)",
                            borderColor: "rgba(75,192,192,1)",
                            borderWidth: 1,
                          },
                        ],
                      };

                      return (
                        <div
                          key={survey.id}
                          style={{
                            marginBottom: "1rem",
                            border: "1px solid #e2e2e2",
                            padding: "0.5rem",
                            borderRadius: "6px",
                          }}
                        >
                          <h5 style={{ margin: "0.5rem 0" }}>
                            {survey.description} (ID: {survey.id})
                          </h5>
                          <p>응답 개수: {surveyResponses.length}</p>

                          {labels.length > 0 ? (
                            <div style={{ maxWidth: "400px", marginTop: "1rem" }}>
                              <Bar data={chartData} />
                            </div>
                          ) : (
                            <p>응답이 없습니다.</p>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      ))}
    </div>
  );
};

export default AdminSurveyResponses;
