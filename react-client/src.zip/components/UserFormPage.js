import React from 'react';
import UserForm from './UserForm';

function UserFormPage() {
  return (
    <div>
      <h2>회원 추가</h2>
      <UserForm />
    </div>
  );
}

export default UserFormPage;